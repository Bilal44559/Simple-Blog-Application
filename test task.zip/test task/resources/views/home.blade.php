@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            @if ($errors->any())
                <div class="alert alert-danger" id="validationErrors">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            @if (session()->has('message'))
                <div class="alert alert-success" id="validationErrors">
                    {{ session('message') }}
                </div>
            @endif
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        {{ __('Posts') }}
                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                            data-bs-target="#addPostModal">Add Post</button>
                    </div>

                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Aunthor</th>
                                    <th>Title</th>
                                    <th>Content</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($posts as $post)
                                    <tr>
                                        <th>{{ $post->id }}</th>
                                        <td>{{ $post->user->name }}</td>
                                        <td>{{ $post->title }}</td>
                                        <td>{{ $post->content }}</td>
                                        <td>
                                            <div class="d-inline-block">
                                                <button type="button" class="btn btn-primary " data-bs-toggle="modal"
                                                    data-bs-target="#editPostModal{{ $post->id }}">Edit Post</button>
                                            </div>
                                            <div class="d-inline-block">
                                                <a href="{{ route('posts.show', $post->id) }}" class="btn btn-info">Info</a>
                                            </div>
                                            <div class="d-inline-block">
                                                <form method="POST" action="{{ route('posts.destroy', $post->id) }}">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    {{-- Edit Post Modal Body --}}
                                    <div class="modal fade" id="editPostModal{{ $post->id }}" tabindex="-1"
                                        aria-labelledby="editPostModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="editPostModalLabel">Edit Post</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form method="POST" action="{{ route('posts.update', $post->id) }}">
                                                    @csrf
                                                    @method('PUT')
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label for="postTitle" class="form-label">Title</label>
                                                            <input type="text" class="form-control" id="postTitle"
                                                                name="title" value="{{ $post->title }}">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="postContent" class="form-label">Content</label>
                                                            <textarea class="form-control" id="postContent" name="content" rows="3">{{ $post->content }}</textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach

                            </tbody>
                        </table>
                    </div>
                    <!-- Modal to add post -->
                    <div class="modal fade" id="addPostModal" tabindex="-1" aria-labelledby="addPostModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addPostModalLabel">Add Post</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form method="POST" action="{{ route('posts.store') }}"> @csrf
                                    <div class="modal-body">

                                        <div class="mb-3">
                                            <label for="postTitle" class="form-label">Title</label>
                                            <input type="text" class="form-control" id="postTitle" name="title">

                                        </div>
                                        <div class="mb-3">
                                            <label for="postContent" class="form-label">Content</label>
                                            <textarea class="form-control" id="postContent" name="content" rows="3"></textarea>

                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            // Hide the alert box after 5 seconds
            setTimeout(function() {
                $("#validationErrors").fadeOut("slow");
            }, 5000);
        });
    </script>
@endsection
