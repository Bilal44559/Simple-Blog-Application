<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success" id="validationErrors">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" id="validationErrors">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(__('Post')); ?>

                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                            data-bs-target="#addPostcomment">Add Comment</button>
                    </div>

                    <div class="card-body">
                        <div class="mb-3">
                            <label for="postTitle" class="form-label">Title</label>
                            <input type="text" readonly class="form-control" id="postTitle" name="title"
                                value="<?php echo e($post->title); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="postContent" class="form-label">Content</label>
                            <textarea class="form-control" readonly id="postContent" name="content" rows="3"><?php echo e($post->content); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <h3>Comments</h3>
                            <?php $__currentLoopData = $post->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="comment">
                                    <p><strong><?php echo e($comment->user->name); ?></strong></p>
                                    <p class="form-control"><?php echo e($comment->content); ?></p>
                                    <?php if($comment->user_id == auth()->user()->id): ?>
                                        <form method="POST" action="<?php echo e(route('comments.destroy', $comment->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger m-1 float-end">Delete</button>
                                        </form>
                                        <button type="button" class="btn btn-primary float-end m-1" data-bs-toggle="modal"
                                            data-bs-target="#editcommentModal<?php echo e($comment->id); ?>">Edit Comment</button>
                                    <?php endif; ?>


                                </div>

                                
                                <div class="modal fade" id="editcommentModal<?php echo e($comment->id); ?>" tabindex="-1"
                                    aria-labelledby="editPostModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editcommentModalLabel">Edit Comment</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <form method="POST" action="<?php echo e(route('comments.update', $comment->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label for="commentContent" class="form-label">Comment</label>
                                                        <textarea class="form-control" id="commentContent" name="content" rows="3"><?php echo e($comment->content); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Modal to add Comment -->
                    <div class="modal fade" id="addPostcomment" tabindex="-1" aria-labelledby="addPostModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addPostcommentLabel">Add Comment</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form method="POST" action="<?php echo e(route('comments.store')); ?>"> <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">

                                        <div class="mb-3">
                                            <label for="postContent" class="form-label">Comment</label>
                                            <textarea class="form-control" id="postContent" name="content" rows="3"></textarea>

                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8.1\htdocs\blog\resources\views/posts/show.blade.php ENDPATH**/ ?>