<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" id="validationErrors">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success" id="validationErrors">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(__('Posts')); ?>

                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                            data-bs-target="#addPostModal">Add Post</button>
                    </div>

                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Aunthor</th>
                                    <th>Title</th>
                                    <th>Content</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($post->id); ?></th>
                                        <td><?php echo e($post->user->name); ?></td>
                                        <td><?php echo e($post->title); ?></td>
                                        <td><?php echo e($post->content); ?></td>
                                        <td>
                                            <div class="d-inline-block">
                                                <button type="button" class="btn btn-primary " data-bs-toggle="modal"
                                                    data-bs-target="#editPostModal<?php echo e($post->id); ?>">Edit Post</button>
                                            </div>
                                            <div class="d-inline-block">
                                                <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-info">Info</a>
                                            </div>
                                            <div class="d-inline-block">
                                                <form method="POST" action="<?php echo e(route('posts.destroy', $post->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    
                                    <div class="modal fade" id="editPostModal<?php echo e($post->id); ?>" tabindex="-1"
                                        aria-labelledby="editPostModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="editPostModalLabel">Edit Post</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form method="POST" action="<?php echo e(route('posts.update', $post->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label for="postTitle" class="form-label">Title</label>
                                                            <input type="text" class="form-control" id="postTitle"
                                                                name="title" value="<?php echo e($post->title); ?>">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="postContent" class="form-label">Content</label>
                                                            <textarea class="form-control" id="postContent" name="content" rows="3"><?php echo e($post->content); ?></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <!-- Modal to add post -->
                    <div class="modal fade" id="addPostModal" tabindex="-1" aria-labelledby="addPostModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addPostModalLabel">Add Post</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form method="POST" action="<?php echo e(route('posts.store')); ?>"> <?php echo csrf_field(); ?>
                                    <div class="modal-body">

                                        <div class="mb-3">
                                            <label for="postTitle" class="form-label">Title</label>
                                            <input type="text" class="form-control" id="postTitle" name="title">

                                        </div>
                                        <div class="mb-3">
                                            <label for="postContent" class="form-label">Content</label>
                                            <textarea class="form-control" id="postContent" name="content" rows="3"></textarea>

                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            // Hide the alert box after 5 seconds
            setTimeout(function() {
                $("#validationErrors").fadeOut("slow");
            }, 5000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_8.1\htdocs\blog\resources\views/home.blade.php ENDPATH**/ ?>