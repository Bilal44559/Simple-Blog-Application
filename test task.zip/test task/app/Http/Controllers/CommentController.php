<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{
    public function store(Request $request)
    {

        $request->validate([
            'content' => 'required',
        ]);

        $comment = new Comment;
        $comment->content = $request->content;
        $comment->user_id = Auth::user()->id;
        $comment->post_id = $request->post_id;
        $comment->save();
        return back()->with('message', 'Comment Created Successfully');
    }
    public function destroy($id)
    {
        $comment = Comment::find($id);
        $comment->delete();

        return back()->with('message', 'Comment Deleted Successfully');
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'content' => 'required',
        ]);


        $comment = Comment::find($id);
        $comment->content = $request->content;
        $comment->save();

        return back()->with('message', 'Comment Updated Successfully');
    }
}
