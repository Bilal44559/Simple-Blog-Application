<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    // Show all Posts code is in HomeController

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'content' => 'required',
        ]);

        $post = new Post;
        $post->title = $request->title;
        $post->content = $request->content;
        $post->user_id = Auth::user()->id;
        $post->save();

        return back()->with('message', 'Post Created Successfully');
    }
    public function destroy($id)
    {
        $post = Post::find($id);
        $post->delete();

        return back()->with('message', 'Post Deleted Successfully');
    }
    public function show($id)
    {
        $post = Post::find($id)->with('comment')->first();
        return view('posts.show', compact('post'));
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'content' => 'required',
        ]);


        $post = Post::find($id);
        $post->title = $request->title;
        $post->content = $request->content;
        $post->save();

        return back()->with('message', 'Post Updated Successfully');
    }
}
